#!/bin/bash	


dobackup(){
	local backup_file=$1
	local path=$2
	local timestamp=$(date +%Y%m%d_%H%M%S)

        if [[ ! -e "$backup_file" ]]; then
		
		echo "ERROR: file that you are tring to back up does not exist"
                return 1
	fi
        
	if [[ ! -d $path ]]; then
		echo "Backup directory does not exist"
		read -p "Do you want to create the directory? y/n"  option
		if [[ $option == 'y' ]]; then
                        echo "new backup directory is beeing created"
			
		else
			echo "try again"
			return 1
		fi

        fi
   local clean_name=$(basename "$backup_file")
   local backup_path="${path}/${clean_name}_${timestamp}.tar.gz"
    
   tar -czvf "$backup_path" "$backup_file"

}



read -p " please enter what file/direcory you want to back up " backup
read -p " please where do you want to save the backup " path
dobackup "$path" "$path"




